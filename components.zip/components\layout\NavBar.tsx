"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useQueryClient } from "@tanstack/react-query";

import {
  Bell,
  LogOut,
  Menu,
  Search,
} from "lucide-react";

import { logout } from "@/app/logout/actions";

interface NavbarProps {
  onOpenMenu: () => void;
}

export default function Navbar({
  onOpenMenu,
}: NavbarProps) {
  const router = useRouter();
  const queryClient = useQueryClient();

  const [loggingOut, setLoggingOut] =
    useState(false);

  async function handleLogout() {
    if (
      !window.confirm(
        "Are you sure you want to log out?"
      )
    ) {
      return;
    }

    setLoggingOut(true);

    try {
      await logout();

      queryClient.clear();

      router.push("/login");
    } catch (err) {
      console.error(err);

      alert("Logout failed.");

      setLoggingOut(false);
    }
  }

  return (
    <header
      className="
        rounded-[24px]
        border
        border-white/[0.05]
        bg-[#0B0F15]/90
        backdrop-blur-2xl
        shadow-[0_16px_50px_rgba(0,0,0,.30)]
      "
    >
      <div className="flex h-12 items-center justify-between px-5">

        {/* Left */}

        <div className="flex items-center gap-3">

          <button
            onClick={onOpenMenu}
            className="flex h-8 w-8 items-center justify-center rounded-xl border border-white/[0.06] bg-white/[0.03] lg:hidden"
          >
            <Menu size={16} />
          </button>

          <div>

            <h1 className="text-[15px] font-semibold tracking-tight text-white">
              Dashboard
            </h1>

            <p className="text-[10px] text-zinc-500">
              Executive Workspace
            </p>

          </div>

        </div>

        {/* Search */}

        <div className="hidden lg:block w-[340px]">

          <div className="flex h-9 items-center gap-3 rounded-xl border border-white/[0.05] bg-white/[0.025] px-3">

            <Search
              size={15}
              className="text-zinc-500"
            />

            <input
              placeholder="Search..."
              className="w-full bg-transparent text-sm outline-none placeholder:text-zinc-600"
            />

          </div>

        </div>

        {/* Right */}

        <div className="flex items-center gap-2">

          <button className="flex h-8 w-8 items-center justify-center rounded-xl border border-white/[0.05] bg-white/[0.025] transition hover:bg-white/[0.05]">

            <Bell size={15} />

          </button>

          <div className="hidden md:flex items-center gap-2 rounded-xl border border-white/[0.05] bg-white/[0.025] px-3 py-1.5">

            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#D4AF37]/15 text-xs font-semibold text-[#D4AF37]">
              A
            </div>

            <div>

              <p className="text-sm font-medium leading-none text-white">
                Administrator
              </p>

              <p className="mt-1 text-[10px] text-zinc-500">
                Executive Workspace
              </p>

            </div>

          </div>

          <button
            onClick={handleLogout}
            disabled={loggingOut}
            className="hidden xl:flex h-8 items-center gap-2 rounded-xl border border-red-500/15 bg-red-500/10 px-3 text-xs text-red-300 transition hover:bg-red-500/20"
          >

            <LogOut size={14} />

            {loggingOut
              ? "Logging..."
              : "Logout"}

          </button>

        </div>

      </div>
    </header>
  );
}