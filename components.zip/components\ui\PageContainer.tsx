import AmbientBackground from "./AmbientBackground";

interface PageContainerProps {
  children: React.ReactNode;
}

export default function PageContainer({
  children,
}: PageContainerProps) {
  return (
    <main className="relative min-h-screen overflow-hidden bg-[#05070C]">

      {/* Ambient Background */}

      <AmbientBackground />

      {/* Layer 1 */}

      <div
        className="absolute inset-0"
        style={{
          background: `
            radial-gradient(circle at top, rgba(255,255,255,.03), transparent 40%),
            linear-gradient(180deg,#090C12 0%,#06080D 45%,#040506 100%)
          `,
        }}
      />

      {/* Layer 2 */}

      <div
        className="absolute inset-0 opacity-[0.22]"
        style={{
          backgroundImage: `
            linear-gradient(rgba(255,255,255,.02) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,255,255,.02) 1px, transparent 1px)
          `,
          backgroundSize: "80px 80px",
        }}
      />

      {/* Content */}

      <div className="relative z-10 px-8 py-10 lg:px-12">

        <div className="mx-auto flex w-full max-w-[1650px] flex-col gap-8">

          {children}

        </div>

      </div>

    </main>
  );
}