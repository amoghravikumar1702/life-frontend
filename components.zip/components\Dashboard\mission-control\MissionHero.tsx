"use client";

import { Sparkles, ArrowUpRight } from "lucide-react";

import FadeIn from "@/components/motion/FadeIn";
import BentoCard from "@/components/ui/BentoCard";
import ExecutiveButton from "@/components/ui/ExecutiveButton";

interface Props {
  revenue: number;
  receivables: number;
}

function money(value: number) {
  return `₹${new Intl.NumberFormat("en-IN", {
    notation: "compact",
    maximumFractionDigits: 1,
  }).format(value)}`;
}

export default function MissionHero({
  revenue,
  receivables,
}: Props) {
  return (
    <FadeIn>
      <BentoCard
        glow="purple"
        hover={false}
        className="relative overflow-hidden px-8 py-6 lg:px-10 lg:py-7"
      >
        {/* Ambient Glow */}

        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(124,58,237,.10),transparent_42%),radial-gradient(circle_at_bottom_right,rgba(212,175,55,.05),transparent_45%)]" />

        <div className="relative flex items-center justify-between gap-10">

          {/* LEFT */}

          <div className="max-w-2xl">

            <div className="flex items-center gap-4">

              <div className="flex h-14 w-14 items-center justify-center rounded-[20px] border border-[#D4AF37]/15 bg-[#D4AF37]/10">

                <Sparkles
                  size={26}
                  className="text-[#D4AF37]"
                />

              </div>

              <div>

                <p className="text-[11px] uppercase tracking-[0.35em] text-zinc-500">
                  Mission Control
                </p>

                <h1 className="mt-1 text-5xl font-semibold tracking-tight text-white">
                  Good Morning
                </h1>

              </div>

            </div>

            <p className="mt-5 max-w-xl text-[15px] leading-7 text-zinc-400">
              Your business is performing well today.
              Recover outstanding receivables,
              monitor cash flow and review AI
              recommendations before making
              financial decisions.
            </p>

            <div className="mt-6 flex flex-wrap gap-3">

              <ExecutiveButton>
                Open AI CFO
              </ExecutiveButton>

              <ExecutiveButton variant="secondary">
                View Reports
              </ExecutiveButton>

            </div>

          </div>

          {/* RIGHT */}

          <div className="hidden xl:block">

            <div className="w-[250px] rounded-[26px] border border-white/[0.05] bg-white/[0.025] p-6 backdrop-blur-xl">

              <div className="flex items-center justify-between">

                <p className="text-xs uppercase tracking-[0.3em] text-zinc-500">
                  Business Overview
                </p>

                <ArrowUpRight
                  size={16}
                  className="text-[#D4AF37]"
                />

              </div>

              <div className="mt-6">

                <p className="text-xs uppercase tracking-[0.25em] text-zinc-500">
                  Revenue
                </p>

                <h2 className="mt-2 text-4xl font-semibold tracking-tight text-white">
                  {money(revenue)}
                </h2>

              </div>

              <div className="my-5 h-px bg-white/[0.06]" />

              <div>

                <p className="text-xs uppercase tracking-[0.25em] text-zinc-500">
                  Receivables
                </p>

                <h3 className="mt-2 text-2xl font-semibold text-white">
                  {money(receivables)}
                </h3>

              </div>

            </div>

          </div>

        </div>

      </BentoCard>
    </FadeIn>
  );
}