"use client";

import {
  ArrowUpRight,
  Clock3,
  Target,
} from "lucide-react";

import BentoCard from "@/components/ui/BentoCard";
import AnimatedNumber from "@/components/ui/AnimatedNumber";

interface Props {
  receivables: number;
}

function money(value: number) {
  return `₹${new Intl.NumberFormat("en-IN", {
    notation: "compact",
    maximumFractionDigits: 1,
  }).format(value)}`;
}

export default function TodaysFocus({
  receivables,
}: Props) {
  return (
    <BentoCard
      glow="gold"
      hover
      className="flex h-[410px] flex-col p-6"
    >
      {/* Header */}

      <div className="flex items-start justify-between">

        <div className="flex items-center gap-4">

          <div className="flex h-12 w-12 items-center justify-center rounded-[18px] border border-[#D4AF37]/15 bg-[#D4AF37]/10">

            <Target
              size={20}
              className="text-[#D4AF37]"
            />

          </div>

          <div>

            <p className="text-[10px] uppercase tracking-[0.35em] text-zinc-500">
              Today's Focus
            </p>

            <h2 className="mt-1 text-2xl font-semibold leading-tight text-white">
              Collect Payments
            </h2>

          </div>

        </div>

        <ArrowUpRight
          size={17}
          className="text-[#D4AF37]"
        />

      </div>

      {/* Description */}

      <p className="mt-5 text-[15px] leading-7 text-zinc-400">
        Recover overdue invoices to improve liquidity,
        strengthen cash flow and improve working capital.
      </p>

      {/* Amount */}

      <div className="mt-auto">

        <div className="text-5xl font-semibold tracking-tight text-white">

          <AnimatedNumber
            value={receivables}
            formatter={money}
          />

        </div>

        <p className="mt-2 text-sm font-medium text-emerald-400">
          Recoverable Today
        </p>

      </div>

      {/* Footer */}

      <div className="mt-6 flex items-center justify-between border-t border-white/[0.06] pt-5">

        <div className="flex items-center gap-2 rounded-full border border-white/[0.06] bg-white/[0.03] px-3 py-2">

          <Clock3
            size={14}
            className="text-zinc-400"
          />

          <span className="text-xs text-zinc-300">
            Highest Priority
          </span>

        </div>

        <span className="text-[10px] uppercase tracking-[0.30em] text-[#D4AF37]">
          ACTION
        </span>

      </div>

    </BentoCard>
  );
}