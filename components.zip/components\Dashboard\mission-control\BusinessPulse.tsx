"use client";

import { motion } from "framer-motion";
import {
  Activity,
  TrendingUp,
  Wallet,
  Users,
  ArrowUpRight,
} from "lucide-react";

interface Snapshot {
  revenue: number;
  cashAvailable: number;
  outstandingReceivables: number;
  customerCount: number;
  healthScore: number;
  trend: "Improving" | "Stable" | "Declining";
}

interface Props {
  snapshot: Snapshot;
}

const money = (value: number) => {
  if (value >= 10000000)
    return `₹${(value / 10000000).toFixed(1)}Cr`;

  if (value >= 100000)
    return `₹${Math.round(value / 100000)}L`;

  if (value >= 1000)
    return `₹${Math.round(value / 1000)}K`;

  return `₹${Math.round(value)}`;
};

export default function BusinessPulse({
  snapshot,
}: Props) {
  const scoreColor =
    snapshot.healthScore >= 85
      ? "text-emerald-400"
      : snapshot.healthScore >= 70
      ? "text-[#D4AF37]"
      : "text-red-400";

  const status =
    snapshot.healthScore >= 85
      ? "Excellent"
      : snapshot.healthScore >= 70
      ? "Healthy"
      : "Needs Attention";

  return (
    <motion.section
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45 }}
      className="flex h-[410px] flex-col rounded-[30px] border border-white/[0.05] bg-[#0E1118]/90 p-6 backdrop-blur-2xl shadow-[0_20px_80px_rgba(0,0,0,.30)]"
    >
      {/* Header */}

      <div className="flex items-start justify-between">

        <div>

          <p className="text-[10px] uppercase tracking-[0.35em] text-zinc-500">
            Executive Snapshot
          </p>

          <div className="mt-3 flex items-end gap-4">

            <h1
              className={`text-6xl font-bold leading-none ${scoreColor}`}
            >
              {snapshot.healthScore}
            </h1>

            <div className="pb-1">

              <p className="text-lg font-medium text-white">
                {status}
              </p>

              <p className="text-sm text-zinc-500">
                Business Health Score
              </p>

            </div>

          </div>

        </div>

        <div className="text-right">

          <p className="text-[10px] uppercase tracking-[0.25em] text-zinc-500">
            Live Status
          </p>

          <div className="mt-3 flex items-center justify-end gap-2">

            <div className="h-2 w-2 rounded-full bg-emerald-400" />

            <span className="text-sm text-white">
              Updated
            </span>

          </div>

        </div>

      </div>

      {/* KPI GRID */}

      <div className="mt-6 grid grid-cols-2 gap-4 xl:grid-cols-4">

        <Metric
          title="Revenue"
          value={money(snapshot.revenue)}
          icon={TrendingUp}
        />

        <Metric
          title="Cash"
          value={money(snapshot.cashAvailable)}
          icon={Wallet}
        />

        <Metric
          title="Receivables"
          value={money(snapshot.outstandingReceivables)}
          icon={Activity}
        />

        <Metric
          title="Customers"
          value={snapshot.customerCount.toString()}
          icon={Users}
        />

      </div>

      {/* Footer */}

      <div className="mt-auto flex items-center justify-between rounded-2xl border border-white/[0.05] bg-white/[0.025] px-5 py-4">

        <div>

          <p className="text-[10px] uppercase tracking-[0.30em] text-zinc-500">
            Business Trend
          </p>

          <h3 className="mt-2 text-lg font-semibold text-white">
            {snapshot.trend}
          </h3>

        </div>

        <div className="flex items-center gap-2 text-[#D4AF37]">

          <ArrowUpRight size={16} />

          <span className="text-sm">
            Executive Overview
          </span>

        </div>

      </div>

    </motion.section>
  );
}

interface MetricProps {
  title: string;
  value: string;
  icon: any;
}

function Metric({
  title,
  value,
  icon: Icon,
}: MetricProps) {
  return (
    <div className="group rounded-[22px] border border-white/[0.05] bg-white/[0.025] p-4 transition-all duration-300 hover:-translate-y-1 hover:border-white/[0.08]">

      <div className="flex items-center justify-between">

        <p className="text-[10px] uppercase tracking-[0.30em] text-zinc-500">
          {title}
        </p>

        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#D4AF37]/10">

          <Icon
            size={16}
            className="text-[#D4AF37]"
          />

        </div>

      </div>

      <h3 className="mt-4 text-[28px] font-semibold tracking-tight text-white">
        {value}
      </h3>

      <p className="mt-2 text-xs text-emerald-400">
        ▲ Healthy
      </p>

    </div>
  );
}