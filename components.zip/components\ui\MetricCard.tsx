import { ReactNode } from "react";

import BentoCard from "./BentoCard";

interface MetricCardProps {
  label: string;

  value: ReactNode;

  change?: string;

  positive?: boolean;

  icon?: ReactNode;
}

export default function MetricCard({
  label,
  value,
  change,
  positive = true,
  icon,
}: MetricCardProps) {
  return (
    <BentoCard
      hover
      className="p-7"
    >
      <div className="flex items-start justify-between">

        <div>

          <p className="text-xs uppercase tracking-[0.25em] text-zinc-500">
            {label}
          </p>

          <div className="mt-5 text-4xl font-semibold tracking-tight text-white">
            {value}
          </div>

          {change && (
            <p
              className={`mt-4 text-sm ${
                positive
                  ? "text-emerald-400"
                  : "text-red-400"
              }`}
            >
              {change}
            </p>
          )}

        </div>

        {icon}

      </div>
    </BentoCard>
  );
}