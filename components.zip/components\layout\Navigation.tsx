"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion } from "framer-motion";

import {
  Activity,
  BarChart3,
  Brain,
  Building2,
  FileBarChart2,
  FileText,
  LayoutDashboard,
  Settings,
  Target,
  TrendingUp,
  Users,
} from "lucide-react";

interface NavigationProps {
  collapsed?: boolean;
  mobile?: boolean;
  onNavigate?: () => void;
}

const sections = [
  {
    title: "Workspace",
    items: [
      {
        label: "Mission Control",
        href: "/dashboard",
        icon: LayoutDashboard,
      },
    ],
  },
  {
    title: "Operations",
    items: [
      {
        label: "Customers",
        href: "/customers",
        icon: Users,
      },
      {
        label: "Invoices",
        href: "/invoices",
        icon: FileText,
      },
    ],
  },
  {
    title: "Intelligence",
    items: [
      {
        label: "AI CFO",
        href: "/dashboard/ai-cfo",
        icon: Brain,
      },
      {
        label: "Business Health",
        href: "/dashboard/business-health",
        icon: Activity,
      },
      {
        label: "Financial Analysis",
        href: "/dashboard/financial-analysis",
        icon: BarChart3,
      },
      {
        label: "Forecast",
        href: "/dashboard/forecast",
        icon: TrendingUp,
      },
      {
        label: "Decision Center",
        href: "/dashboard/decision-center",
        icon: Target,
      },
      {
        label: "Executive Reports",
        href: "/dashboard/reports",
        icon: FileBarChart2,
      },
    ],
  },
  {
    title: "Company",
    items: [
      {
        label: "Company",
        href: "/company",
        icon: Building2,
      },
      {
        label: "Settings",
        href: "/settings",
        icon: Settings,
      },
    ],
  },
];

export default function Navigation({
  collapsed = false,
  onNavigate,
}: NavigationProps) {
  const pathname = usePathname();

  return (
    <nav className="space-y-8">

      {sections.map((section) => (

        <div key={section.title}>

          {!collapsed && (

            <p className="mb-3 px-4 text-[10px] uppercase tracking-[0.38em] text-zinc-600">
              {section.title}
            </p>

          )}

          <div className="space-y-1.5">

            {section.items.map((item) => {
              const Icon = item.icon;

              const active =
                pathname === item.href ||
                pathname.startsWith(`${item.href}/`);

              return (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={onNavigate}
                  title={collapsed ? item.label : undefined}
                >
                  <motion.div
                    whileHover={{
                      x: collapsed ? 0 : 4,
                    }}
                    transition={{
                      duration: 0.18,
                    }}
                    className={`
                      relative
                      flex
                      h-12
                      items-center
                      rounded-2xl
                      transition-all
                      duration-300
                      ${
                        collapsed
                          ? "justify-center"
                          : "gap-3 px-4"
                      }
                      ${
                        active
                          ? "bg-gradient-to-r from-[#D4AF37]/12 to-transparent text-white border border-[#D4AF37]/15"
                          : "text-zinc-500 hover:bg-white/[0.03] hover:text-white"
                      }
                    `}
                  >

                    {active && (
                      <span className="absolute left-0 top-2 bottom-2 w-1 rounded-r-full bg-[#D4AF37]" />
                    )}

                    <Icon
                      size={18}
                      className={`
                        transition-all
                        duration-300
                        ${
                          active
                            ? "text-[#D4AF37]"
                            : "group-hover:text-white"
                        }
                      `}
                    />

                    {!collapsed && (
                      <span className="text-[14px] font-medium tracking-[0.01em]">
                        {item.label}
                      </span>
                    )}

                  </motion.div>

                </Link>
              );
            })}

          </div>

        </div>

      ))}

    </nav>
  );
}