import { ReactNode } from "react";

interface PageHeaderProps {
  eyebrow?: string;

  title: string;

  subtitle?: string;

  description?: string;

  actions?: ReactNode;
}

export default function PageHeader({
  eyebrow,
  title,
  subtitle,
  description,
  actions,
}: PageHeaderProps) {
  return (
    <header className="mb-10 flex items-end justify-between gap-8">

      <div>

        {eyebrow && (
          <p className="mb-3 text-xs uppercase tracking-[0.35em] text-zinc-500">
            {eyebrow}
          </p>
        )}

        <h1 className="text-5xl font-semibold tracking-tight text-white">
          {title}
        </h1>

        {(subtitle || description) && (
          <p className="mt-4 max-w-3xl text-[15px] leading-8 text-zinc-400">
            {subtitle ?? description}
          </p>
        )}

      </div>

      {actions}

    </header>
  );
}