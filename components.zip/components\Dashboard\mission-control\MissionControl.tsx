import MissionHero from "./MissionHero";
import TodaysFocus from "./TodaysFocus";
import BusinessPulse from "./BusinessPulse";
import QuickActions from "./QuickActions";
import ActivityCenter from "./ActivityCenter";

import { getDashboardData } from "@/lib/dashboard";
import { getActivityFeed } from "@/lib/server";

export default async function MissionControl() {
  const [{ snapshot }, activityFeed] = await Promise.all([
    getDashboardData(),
    getActivityFeed(),
  ]);

  const activity = activityFeed.filter(
    (
      item
    ): item is Extract<
      (typeof activityFeed)[number],
      {
        type: "payment" | "customer" | "invoice";
      }
    > => item.type !== "reminder"
  );

  return (
    <div className="mx-auto w-full max-w-[1600px] space-y-6">

      <MissionHero
        revenue={snapshot.revenue}
        receivables={snapshot.outstandingReceivables}
      />

      <div className="grid gap-6 xl:grid-cols-[360px_1fr]">

        <TodaysFocus
          receivables={snapshot.outstandingReceivables}
        />

        <BusinessPulse
          snapshot={snapshot}
        />

      </div>

      <div className="grid gap-6 xl:grid-cols-[420px_1fr]">

        <QuickActions />

        <ActivityCenter
          activity={activity}
        />

      </div>

    </div>
  );
}