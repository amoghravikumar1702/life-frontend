import Link from "next/link";

import {
  ArrowRight,
  CreditCard,
  FileText,
  UserPlus,
} from "lucide-react";

import BentoCard from "@/components/ui/BentoCard";

const actions = [
  {
    title: "Create Invoice",
    subtitle: "Generate a new invoice",
    href: "/invoices/new",
    icon: FileText,
  },
  {
    title: "Collect Payment",
    subtitle: "Recover receivables",
    href: "/invoices",
    icon: CreditCard,
  },
  {
    title: "Add Customer",
    subtitle: "Create customer profile",
    href: "/customers/new",
    icon: UserPlus,
  },
];

export default function QuickActions() {
  return (
    <section>

      <div className="mb-5">

        <p className="text-[10px] uppercase tracking-[0.35em] text-zinc-500">
          Executive Commands
        </p>

        <h2 className="mt-2 text-2xl font-semibold tracking-tight text-white">
          Quick Actions
        </h2>

      </div>

      <div className="grid gap-4 md:grid-cols-3">

        {actions.map((action) => {
          const Icon = action.icon;

          return (
            <Link
              key={action.title}
              href={action.href}
              className="group"
            >
              <BentoCard
                hover
                className="h-[170px] p-5 transition-all duration-300"
              >

                <div className="flex items-center justify-between">

                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#D4AF37]/10">

                    <Icon
                      size={18}
                      className="text-[#D4AF37]"
                    />

                  </div>

                  <ArrowRight
                    size={16}
                    className="text-zinc-600 transition-all duration-300 group-hover:translate-x-1 group-hover:text-[#D4AF37]"
                  />

                </div>

                <div className="mt-6">

                  <h3 className="text-lg font-semibold text-white">
                    {action.title}
                  </h3>

                  <p className="mt-2 text-sm leading-6 text-zinc-400">
                    {action.subtitle}
                  </p>

                </div>

              </BentoCard>
            </Link>
          );
        })}

      </div>

    </section>
  );
}