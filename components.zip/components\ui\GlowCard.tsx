import { ReactNode } from "react";
import clsx from "clsx";

interface GlowCardProps {
  children: ReactNode;
  className?: string;
  hover?: boolean;

  glow?: "purple" | "blue" | "gold" | "green" | "none";

  strength?: "low" | "medium" | "high";
}

const glowMap = {
  purple: {
    color: "111,91,255",
  },
  blue: {
    color: "37,99,235",
  },
  gold: {
    color: "212,175,55",
  },
  green: {
    color: "34,197,94",
  },
};

export default function GlowCard({
  children,
  className,
  hover = true,
  glow = "none",
  strength = "medium",
}: GlowCardProps) {
  const opacity =
    strength === "high"
      ? 0.45
      : strength === "medium"
      ? 0.28
      : 0.18;

  return (
    <div className="relative isolate">

      {glow !== "none" && (
        <>
          {/* OUTER HALO */}

          <div
            className="absolute -inset-6 -z-20 rounded-[42px] blur-[55px]"
            style={{
              background: `rgba(${glowMap[glow].color},${opacity})`,
            }}
          />

          {/* BORDER GLOW */}

          <div
            className="absolute -inset-[1px] -z-10 rounded-[34px]"
            style={{
              background: `linear-gradient(
                145deg,
                rgba(${glowMap[glow].color},0.45),
                transparent 35%,
                transparent 65%,
                rgba(${glowMap[glow].color},0.18)
              )`,
            }}
          />
        </>
      )}

      <div
        className={clsx(
          "relative overflow-hidden",
          "rounded-[34px]",
          "border border-white/[0.08]",
          "bg-[#0D1117]/90",
          "backdrop-blur-3xl",
          "shadow-[0_18px_60px_rgba(0,0,0,.45)]",
          "transition-all duration-500",
          hover &&
            "hover:-translate-y-1 hover:shadow-[0_35px_80px_rgba(0,0,0,.55)]",
          className
        )}
      >
        {/* TOP SHINE */}

        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/30 to-transparent" />

        {children}
      </div>
    </div>
  );
}