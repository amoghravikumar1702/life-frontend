"use client";

import { ChevronLeft, ChevronRight } from "lucide-react";
import Navigation from "./Navigation";

interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
}

export default function Sidebar({
  collapsed,
  onToggle,
}: SidebarProps) {
  return (
    <aside
      className={`
        hidden lg:block
        shrink-0
        transition-all duration-500 ease-out
        ${collapsed ? "w-[88px]" : "w-[256px]"}
      `}
    >
      <div
        className="
          fixed
          left-5
          top-5
          bottom-5
          flex
          flex-col
          rounded-[30px]
          border
          border-white/[0.05]
          bg-[#0B0F15]/90
          backdrop-blur-2xl
          shadow-[0_24px_90px_rgba(0,0,0,.45)]
          transition-all
          duration-500
        "
        style={{
          width: collapsed ? 72 : 236,
        }}
      >
        {/* Logo */}

        <div className="relative px-6 pt-8 pb-7">

          {collapsed ? (

            <div className="flex justify-center">

              <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-[#D4AF37]/15 bg-[#D4AF37]/10 text-lg font-semibold text-[#D4AF37]">
                F
              </div>

            </div>

          ) : (

            <>
              <h1 className="text-[30px] font-semibold tracking-tight text-white">
                FINZURA
              </h1>

              <p className="mt-2 text-[11px] uppercase tracking-[0.38em] text-zinc-500">
                Executive OS
              </p>
            </>

          )}

        </div>

        {/* Divider */}

        <div className="mx-5 h-px bg-white/[0.05]" />

        {/* Navigation */}

        <div className="flex-1 overflow-y-auto px-3 py-5">

          <Navigation collapsed={collapsed} />

        </div>

        {/* Footer */}

        <div className="border-t border-white/[0.05] p-4">

          {collapsed ? (

            <div className="flex justify-center">

              <div className="flex h-11 w-11 items-center justify-center rounded-2xl border border-[#D4AF37]/15 bg-[#D4AF37]/10 font-semibold text-[#D4AF37]">
                A
              </div>

            </div>

          ) : (

            <div className="rounded-2xl border border-white/[0.05] bg-white/[0.025] p-3 transition-all duration-300 hover:border-white/[0.08] hover:bg-white/[0.04]">

              <div className="flex items-center gap-3">

                <div className="flex h-11 w-11 items-center justify-center rounded-2xl border border-[#D4AF37]/15 bg-[#D4AF37]/10 font-semibold text-[#D4AF37]">
                  A
                </div>

                <div>

                  <p className="text-sm font-medium text-white">
                    Administrator
                  </p>

                  <p className="text-xs text-zinc-500">
                    Executive Workspace
                  </p>

                </div>

              </div>

            </div>

          )}

        </div>

        {/* Toggle Button */}

        <button
          onClick={onToggle}
          className="
            absolute
            -right-3
            top-10
            flex
            h-8
            w-8
            items-center
            justify-center
            rounded-full
            border
            border-white/[0.08]
            bg-[#12161D]
            text-zinc-300
            shadow-[0_10px_30px_rgba(0,0,0,.45)]
            transition-all
            duration-300
            hover:scale-105
            hover:border-white/20
            hover:bg-[#171C24]
            hover:text-white
          "
        >
          {collapsed ? (
            <ChevronRight size={15} />
          ) : (
            <ChevronLeft size={15} />
          )}
        </button>

      </div>

    </aside>
  );
}