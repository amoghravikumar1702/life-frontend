interface StatusBadgeProps {
  label?: string;

  status: string;
}

export default function StatusBadge({
  label,
  status,
}: StatusBadgeProps) {
  const normalized = status.toLowerCase();

  const styles: Record<string, string> = {
    paid: "bg-emerald-500/10 text-emerald-400",
    completed: "bg-emerald-500/10 text-emerald-400",
    success: "bg-emerald-500/10 text-emerald-400",

    pending: "bg-amber-500/10 text-amber-400",
    warning: "bg-amber-500/10 text-amber-400",

    overdue: "bg-red-500/10 text-red-400",
    failed: "bg-red-500/10 text-red-400",
    danger: "bg-red-500/10 text-red-400",

    draft: "bg-sky-500/10 text-sky-400",
    info: "bg-sky-500/10 text-sky-400",
  };

  return (
    <span
      className={`inline-flex items-center rounded-full px-3 py-1 text-xs font-medium capitalize ${
        styles[normalized] ??
        "bg-zinc-700/30 text-zinc-300"
      }`}
    >
      {label ?? status}
    </span>
  );
}