"use client";

import { ArrowUpRight } from "lucide-react";

import FadeIn from "@/components/motion/FadeIn";
import BentoCard from "@/components/ui/BentoCard";
import ExecutiveButton from "@/components/ui/ExecutiveButton";

interface Props {
  revenue: number;
  receivables: number;
}

function money(value: number) {
  return `₹${new Intl.NumberFormat("en-IN", {
    notation: "compact",
    maximumFractionDigits: 1,
  }).format(value)}`;
}

export default function MissionHero({
  revenue,
  receivables,
}: Props) {
  return (
    <FadeIn>
      <BentoCard
        glow="purple"
        hover={false}
        className="relative overflow-hidden px-8 py-6 lg:px-10 lg:py-7"
      >
        {/* Ambient Glow */}

        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(124,58,237,.10),transparent_42%),radial-gradient(circle_at_bottom_right,rgba(212,175,55,.05),transparent_45%)]" />

        <div className="relative flex items-center justify-between gap-10">

          {/* LEFT */}

<div className="max-w-3xl">

  <p className="text-[11px] font-medium uppercase tracking-[0.42em] text-[#D4AF37]">
    MISSION CONTROL
  </p>

  <h1 className="mt-5 text-[56px] font-bold leading-[0.95] tracking-[-0.04em] text-white">
    Good Evening,
    <br />
    Amogh.
  </h1>

  <p className="mt-6 max-w-2xl text-[17px] leading-8 text-zinc-400">
    Your business generated{" "}
    <span className="font-semibold text-white">
      {money(revenue)}
    </span>{" "}
    in revenue.

    AI CFO has identified{" "}
    <span className="text-[#D4AF37]">
      three high-impact financial decisions
    </span>{" "}
    that require your attention today.
  </p>

  <div className="mt-8 flex flex-wrap gap-3">

    <ExecutiveButton>
      Open AI CFO
    </ExecutiveButton>

    <ExecutiveButton variant="secondary">
      Executive Reports
    </ExecutiveButton>

  </div>

  {/* KPI Ribbon */}

  <div className="mt-10 grid grid-cols-2 gap-4 lg:grid-cols-4">

    <div className="rounded-2xl border border-white/[0.05] bg-white/[0.025] px-5 py-4">

      <p className="text-[10px] uppercase tracking-[0.28em] text-zinc-500">
        Revenue
      </p>

      <h3 className="mt-3 text-2xl font-semibold text-white">
        {money(revenue)}
      </h3>

    </div>

    <div className="rounded-2xl border border-white/[0.05] bg-white/[0.025] px-5 py-4">

      <p className="text-[10px] uppercase tracking-[0.28em] text-zinc-500">
        Outstanding
      </p>

      <h3 className="mt-3 text-2xl font-semibold text-white">
        {money(receivables)}
      </h3>

    </div>

    <div className="rounded-2xl border border-white/[0.05] bg-white/[0.025] px-5 py-4">

      <p className="text-[10px] uppercase tracking-[0.28em] text-zinc-500">
        Health
      </p>

      <h3 className="mt-3 text-2xl font-semibold text-emerald-400">
        91
      </h3>

    </div>

    <div className="rounded-2xl border border-white/[0.05] bg-white/[0.025] px-5 py-4">

      <p className="text-[10px] uppercase tracking-[0.28em] text-zinc-500">
        AI Confidence
      </p>

      <h3 className="mt-3 text-2xl font-semibold text-[#D4AF37]">
        96%
      </h3>

    </div>

  </div>

</div>
         {/* Executive KPI Panel */}

<div className="hidden xl:flex w-[360px] flex-col rounded-[28px] border border-white/[0.06] bg-white/[0.03] p-7 backdrop-blur-2xl">

  <div className="flex items-center justify-between">

    <div>

      <p className="text-[10px] uppercase tracking-[0.35em] text-zinc-500">
        Executive Status
      </p>

      <h3 className="mt-2 text-lg font-semibold text-white">
        Business Overview
      </h3>

    </div>

    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500/10">

      <ArrowUpRight
        size={16}
        className="text-emerald-400"
      />

    </div>

  </div>

  <div className="mt-8 space-y-5">

    <div className="flex items-center justify-between">

      <span className="text-sm text-zinc-500">
        Revenue
      </span>

      <span className="text-2xl font-semibold text-white">
        {money(revenue)}
      </span>

    </div>

    <div className="h-px bg-white/[0.06]" />

    <div className="flex items-center justify-between">

      <span className="text-sm text-zinc-500">
        Outstanding
      </span>

      <span className="text-xl font-semibold text-white">
        {money(receivables)}
      </span>

    </div>

    <div className="h-px bg-white/[0.06]" />

    <div className="flex items-center justify-between">

      <span className="text-sm text-zinc-500">
        Business Health
      </span>

      <span className="rounded-full bg-emerald-500/10 px-3 py-1 text-sm font-medium text-emerald-400">
        Excellent
      </span>

    </div>

    <div className="h-px bg-white/[0.06]" />

    <div className="flex items-center justify-between">

      <span className="text-sm text-zinc-500">
        AI Confidence
      </span>

      <span className="text-[#D4AF37] font-semibold">
        96%
      </span>

    </div>

  </div>

</div>
        </div>

      </BentoCard>
    </FadeIn>
  );
}