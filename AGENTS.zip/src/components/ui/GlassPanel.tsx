import { ReactNode } from "react";
import clsx from "clsx";

interface GlassPanelProps {
  children: ReactNode;
  className?: string;
}

export default function GlassPanel({
  children,
  className,
}: GlassPanelProps) {
  return (
    <div
      className={clsx(
        "relative overflow-hidden rounded-[var(--radius-lg)]",
        "border border-[var(--border)]",
        "bg-[var(--glass-bg)]",
        "backdrop-blur-2xl",
        "shadow-[var(--shadow-card)]",
        className
      )}
    >
      {/* Gloss Layer */}
      <div
        className="
          pointer-events-none
          absolute
          inset-0
          rounded-[inherit]
          bg-gradient-to-b
          from-white/10
          via-white/4
          to-transparent
        "
      />

      {/* Inner Highlight */}
      <div
        className="
          pointer-events-none
          absolute
          inset-[1px]
          rounded-[inherit]
          border
          border-white/5
        "
      />

      <div className="relative z-10">
        {children}
      </div>
    </div>
  );
}