"use client";

import BriefHeader from "./BriefHeader";
import MetricChip from "./MetricChip";

import {
  IndianRupee,
  Wallet,
  Landmark,
  TrendingUp,
} from "lucide-react";

export default function FinancialBrief() {
  return (
    <section className="rounded-[36px] border border-neutral-200/70 bg-white/70 p-10 backdrop-blur-xl">

      <BriefHeader />

      <div className="mt-10 grid gap-5 md:grid-cols-2 xl:grid-cols-4">

        <MetricChip
          label="Revenue"
          value="₹4.20L"
          icon={TrendingUp}
          accent="success"
        />

        <MetricChip
          label="Collections"
          value="₹48K"
          icon={IndianRupee}
        />

        <MetricChip
          label="Expenses"
          value="₹1.80L"
          icon={Wallet}
          accent="warning"
        />

        <MetricChip
          label="Cash Health"
          value="Healthy"
          icon={Landmark}
          accent="success"
        />

      </div>

    </section>
  );
}