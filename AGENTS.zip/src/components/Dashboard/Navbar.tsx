"use client";

import { Bell, LogOut, Search } from "lucide-react";
import { logout } from "@/app/logout/actions";

export default function Navbar() {
  return (
    <header className="sticky top-0 z-40">
      <div className="flex h-20 items-center justify-between rounded-3xl border border-white/10 bg-white/5 px-8 backdrop-blur-xl">
        {/* Left */}
        <div>
          <p className="text-xs uppercase tracking-[0.3em] text-zinc-500">
            Financial Operating System
          </p>

          <h1 className="mt-1 text-2xl font-semibold tracking-tight text-white">
            Dashboard
          </h1>
        </div>

        {/* Right */}
        <div className="flex items-center gap-4">
          {/* Search */}
          <div className="flex h-11 w-80 items-center gap-3 rounded-2xl border border-white/10 bg-white/5 px-4">
            <Search size={18} className="text-zinc-500" />

            <input
              type="text"
              placeholder="Search customers, invoices..."
              className="w-full bg-transparent text-sm text-white placeholder:text-zinc-500 outline-none"
            />
          </div>

          {/* Notifications */}
          <button className="flex h-11 w-11 items-center justify-center rounded-2xl border border-white/10 bg-white/5 transition hover:bg-white/10">
            <Bell size={18} className="text-zinc-300" />
          </button>

          {/* Profile */}
          <div className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/5 px-4 py-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-amber-500/20 font-semibold text-amber-300">
              A
            </div>

            <div className="text-left">
              <p className="text-sm font-medium text-white">Account</p>
              <p className="text-xs text-zinc-500">Administrator</p>
            </div>
          </div>

          {/* Logout */}
          <form action={logout}>
            <button
              type="submit"
              className="flex h-11 items-center gap-2 rounded-2xl border border-red-500/20 bg-red-500/10 px-4 text-sm font-medium text-red-300 transition hover:bg-red-500/20"
            >
              <LogOut size={16} />
              Logout
            </button>
          </form>
        </div>
      </div>
    </header>
  );
}