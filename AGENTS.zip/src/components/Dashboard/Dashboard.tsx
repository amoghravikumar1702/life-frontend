"use client";

import FinancialBrief from "./financial-brief/FinancialBrief";
import { financialBriefMock } from "./financial-brief/mock";
import { useDashboard } from "./queries/dashboardQueries";

export default function Dashboard() {
  const {
    data: stats,
    isLoading,
    error,
  } = useDashboard();

  if (isLoading) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#050505]">
        <h2 className="text-lg text-[#8A8A8F]">
          Loading Dashboard...
        </h2>
      </main>
    );
  }

  if (error || !stats) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#050505]">
        <h2 className="text-lg text-red-400">
          Failed to load dashboard.
        </h2>
      </main>
    );
  }

  return (
    <main className="relative min-h-screen overflow-hidden bg-[#050505]">
      {/* Ambient Lighting */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -left-40 -top-40 h-[700px] w-[700px] rounded-full bg-[#D4AF37]/10 blur-[180px]" />

        <div className="absolute -bottom-60 -right-40 h-[700px] w-[700px] rounded-full bg-white/[0.03] blur-[220px]" />

        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,rgba(255,255,255,0.03),transparent_65%)]" />

        <div className="absolute inset-0 bg-[linear-gradient(to_bottom,rgba(255,255,255,0.02),transparent_20%,transparent_80%,rgba(0,0,0,0.4))]" />
      </div>

      <div className="relative z-10 mx-auto max-w-7xl px-8 pt-28 pb-20">
        <FinancialBrief data={financialBriefMock} />
      </div>
    </main>
  );
}