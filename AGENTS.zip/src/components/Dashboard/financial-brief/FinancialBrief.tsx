"use client";

import FinancialSummary from "./FinancialSummary";
import type { FinancialBriefData } from "./types";

interface FinancialBriefProps {
  data: FinancialBriefData;
}

export default function FinancialBrief({
  data,
}: FinancialBriefProps) {
  return (
    <section
      className="
        relative
        overflow-hidden

        rounded-[36px]

        border
        border-white/[0.08]

        bg-[rgba(18,18,20,0.45)]

        backdrop-blur-[55px]

        shadow-[0_40px_120px_rgba(0,0,0,0.75)]
      "
    >
      {/* Crystal Inner Border */}
      <div
        className="
          pointer-events-none
          absolute
          inset-[1px]
          rounded-[35px]
          border
          border-white/[0.05]
        "
      />

      {/* Glass Reflection */}
      <div
        className="
          pointer-events-none
          absolute
          inset-0
          rounded-[36px]
          bg-gradient-to-br
          from-white/[0.08]
          via-white/[0.015]
          to-transparent
        "
      />

      {/* Gold Ambient Glow */}
      <div
        className="
          pointer-events-none
          absolute
          -top-36
          -right-28
          h-[420px]
          w-[420px]
          rounded-full
          bg-[#D4AF37]/10
          blur-[180px]
        "
      />

      {/* Soft White Ambient Glow */}
      <div
        className="
          pointer-events-none
          absolute
          -bottom-44
          -left-24
          h-[420px]
          w-[420px]
          rounded-full
          bg-white/[0.035]
          blur-[180px]
        "
      />

      {/* Top Crystal Shine */}
      <div
        className="
          pointer-events-none
          absolute
          left-0
          right-0
          top-0
          h-px
          bg-gradient-to-r
          from-transparent
          via-white/40
          to-transparent
        "
      />

      <div className="relative z-10 px-12 pt-9 pb-12">
        <FinancialSummary
          generatedAt={data.generatedAt}
          summary={data.summary}
        />

        {/* Metrics */}
        <div className="mt-14">
          {/* Coming Soon */}
        </div>

        {/* Divider */}
        <div className="mt-16 mb-12 h-px bg-white/[0.05]" />

        {/* AI Insight */}
        <div>
          {/* Coming Soon */}
        </div>
      </div>
    </section>
  );
}