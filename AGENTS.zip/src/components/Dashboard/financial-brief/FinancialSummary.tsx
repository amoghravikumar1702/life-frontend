"use client";

import { motion } from "framer-motion";

interface FinancialSummaryProps {
  generatedAt: string;
  summary: string;
}

export default function FinancialSummary({
  generatedAt,
  summary,
}: FinancialSummaryProps) {
  const hour = new Date().getHours();

  const greeting =
    hour < 12
      ? "Good morning"
      : hour < 17
      ? "Good afternoon"
      : "Good evening";

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        duration: 0.45,
        ease: "easeOut",
      }}
      className="space-y-14"
    >
      <div className="flex items-start justify-between">
        <div className="space-y-4">
          <p
            className="
              font-mono
              text-[13px]
              font-medium
              tracking-[0.18em]
              text-[#868686]
            "
          >
            {greeting}
          </p>

          <h2
            className="
              font-ui
              text-[15px]
              font-semibold
              tracking-[0.16em]
              uppercase
              text-[#D4AF37]
            "
          >
            Financial Brief
          </h2>
        </div>

        <span
          className="
            font-mono
            text-[13px]
            text-[#868686]
          "
        >
          {generatedAt}
        </span>
      </div>

      <p
        className="
          font-editorial

          max-w-[980px]

          text-[22px]

          leading-[36px]

          font-medium

          tracking-[-0.015em]

          text-[#DDD7CC]

          text-balance
        "
      >
        {summary}
      </p>
    </motion.div>
  );
}