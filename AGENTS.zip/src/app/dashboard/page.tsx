import { redirect } from "next/navigation";

import Dashboard from "@/components/Dashboard/Dashboard";
import Navbar from "@/components/Dashboard/Navbar";
import { createClient } from "@/lib/supabase/server";

export default async function DashboardPage() {
  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/login");
  }

  return (
    <main className="min-h-screen bg-[#0B0B0C]">
      <Navbar />
      <Dashboard />
    </main>
  );
}