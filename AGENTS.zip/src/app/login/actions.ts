"use server";

import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export async function signIn(formData: FormData): Promise<void> {
  try {
    const supabase = await createClient();

    const email = String(formData.get("email"));
    const password = String(formData.get("password"));

    console.log("========== LOGIN ATTEMPT ==========");
    console.log("Email:", email);

    const result = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    console.log("LOGIN RESULT:", result);

    if (result.error) {
      console.error("LOGIN ERROR:", result.error);
      throw new Error(result.error.message);
    }

    console.log("LOGIN SUCCESS");
    console.log("REDIRECTING TO DASHBOARD...");

    redirect("/dashboard");
  } catch (error) {
    console.error("SERVER ACTION ERROR:", error);
    throw error;
  }
}