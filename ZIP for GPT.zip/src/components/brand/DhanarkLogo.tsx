"use client";

import Link from "next/link";

type DhanarkLogoVariant =
  | "full"
  | "mark"
  | "wordmark";

interface DhanarkLogoProps {
  variant?: DhanarkLogoVariant;
  href?: string | null;
  className?: string;
  priority?: boolean;
}

const logoSources: Record<
  DhanarkLogoVariant,
  string
> = {
  full: "/brand/dhanark-full.png",
  mark: "/brand/dhanark-mark.png",
  wordmark: "/brand/dhanark-full.png",
};

export default function DhanarkLogo({
  variant = "full",
  href = "/",
  className = "",
}: DhanarkLogoProps) {
  const image = (
    <img
      src={logoSources[variant]}
      alt="Dhanark"
      draggable={false}
      className={`block h-auto w-auto object-contain ${className}`}
    />
  );

  if (!href) {
    return image;
  }

  return (
    <Link
      href={href}
      aria-label="Dhanark home"
      className="inline-flex shrink-0"
    >
      {image}
    </Link>
  );
}