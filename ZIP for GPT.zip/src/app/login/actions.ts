"use server";

import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export async function signIn(
  formData: FormData
): Promise<void> {
  const supabase =
    await createClient();

  const email = String(
    formData.get("email") ?? ""
  ).trim();

  const password = String(
    formData.get("password") ?? ""
  );

  if (!email || !password) {
    throw new Error(
      "Email and password are required."
    );
  }

  /*
   * ============================================================
   * SIGN IN
   * ============================================================
   */

  const {
    data,
    error,
  } =
    await supabase.auth.signInWithPassword(
      {
        email,
        password,
      }
    );

  if (error) {
    console.error(
      "[Login] Sign-in failed:",
      error.message
    );

    throw new Error(
      error.message
    );
  }

  if (!data.session || !data.user) {
    console.error(
      "[Login] Supabase returned no session."
    );

    throw new Error(
      "Login succeeded but no session was created. Please try again."
    );
  }

  const userId =
    data.user.id;

  console.log(
    "[Login] Successful:",
    userId
  );

  /*
   * ============================================================
   * CHECK EXISTING DhanarkOS TRIAL / SUBSCRIPTION
   * ============================================================
   *
   * Existing customers should go to the dashboard.
   *
   * New accounts that have never selected a plan should go
   * through pricing first.
   */

  const {
    data: trial,
    error: trialError,
  } =
    await supabase
      .from("dhanarkos_trials")
      .select(
        "id, trial_status, subscription_status, razorpay_subscription_id"
      )
      .eq(
        "user_id",
        userId
      )
      .maybeSingle();

  if (trialError) {
    console.error(
      "[Login] Trial lookup failed:",
      trialError
    );

    /*
     * Do not block a legitimate login because the trial lookup
     * failed. The dashboard's access layer will handle the
     * account state.
     */

    redirect("/dashboard");
  }

  /*
   * ============================================================
   * EXISTING SUBSCRIPTION / TRIAL
   * ============================================================
   */

  if (trial) {
    console.log(
      "[Login] Existing DhanarkOS trial found."
    );

    redirect("/dashboard");
  }

  /*
   * ============================================================
   * NEW ACCOUNT
   * ============================================================
   *
   * No DhanarkOS trial exists yet.
   *
   * The user must select a plan and authorize the 7-day trial
   * before onboarding.
   */

  console.log(
    "[Login] No DhanarkOS trial found. Sending to pricing."
  );

  redirect("/pricing");
}