import Link from "next/link";
import { signIn } from "./actions";
import DhanarkLogo from "@/components/brand/DhanarkLogo";

export default function LoginPage() {
  return (
    <main className="relative flex min-h-screen overflow-hidden bg-[#090A0B] text-white">
      {/* Ambient lighting */}
      <div className="pointer-events-none absolute left-1/2 top-[-280px] h-[560px] w-[760px] -translate-x-1/2 rounded-full bg-[#D4AF37]/[0.045] blur-[140px]" />

      <div className="pointer-events-none absolute bottom-[-240px] right-[-180px] h-[460px] w-[460px] rounded-full bg-[#D4AF37]/[0.025] blur-[130px]" />

      <div className="relative z-10 mx-auto flex w-full max-w-7xl items-center justify-center px-6 py-12 sm:px-10 lg:px-16">
        <div className="grid w-full max-w-5xl overflow-hidden rounded-[32px] border border-white/[0.08] bg-white/[0.025] shadow-[0_30px_100px_rgba(0,0,0,0.45)] backdrop-blur-2xl lg:grid-cols-[1.05fr_0.95fr]">
          {/* ========================================================
              BRAND PANEL
          ======================================================== */}
          <div className="relative hidden overflow-hidden border-r border-white/[0.06] p-12 lg:flex lg:flex-col lg:justify-between xl:p-16">
            <div className="pointer-events-none absolute bottom-[-180px] left-[-140px] h-[420px] w-[420px] rounded-full bg-[#D4AF37]/[0.035] blur-[120px]" />

            <div className="relative">
              <DhanarkLogo
                variant="full"
                href="/"
                className="h-11 w-auto"
                priority
              />

              <div className="mt-20 max-w-md">
                <p className="text-[10px] font-medium uppercase tracking-[0.4em] text-[#D4AF37]">
                  Financial Intelligence
                </p>

                <h2 className="mt-5 text-4xl font-light leading-[1.12] tracking-[-0.035em] text-zinc-100 xl:text-5xl">
                  Your business.
                  <br />
                  <span className="text-zinc-500">
                    Understood.
                  </span>
                </h2>

                <p className="mt-7 max-w-sm text-sm leading-7 text-zinc-500">
                  DhanarkOS brings your financial operations,
                  business intelligence, and AI CFO into one
                  executive workspace.
                </p>
              </div>
            </div>

            <div className="relative">
              <div className="h-px w-16 bg-[#D4AF37]/50" />

              <p className="mt-4 text-[10px] uppercase tracking-[0.3em] text-zinc-600">
                Executive Intelligence
              </p>
            </div>
          </div>

          {/* ========================================================
              LOGIN
          ======================================================== */}
          <div className="flex items-center p-7 sm:p-10 lg:p-12 xl:p-16">
            <form action={signIn} className="w-full">
              {/* Mobile brand */}
              <div className="mb-12 flex items-center lg:hidden">
                <DhanarkLogo
                  variant="full"
                  href="/"
                  className="h-10 w-auto"
                />
              </div>

              {/* Heading */}
              <div>
                <p className="text-[10px] font-medium uppercase tracking-[0.35em] text-[#D4AF37]">
                  Secure Access
                </p>

                <h1 className="mt-4 text-3xl font-light tracking-[-0.03em] text-zinc-100 sm:text-4xl">
                  Welcome back
                </h1>

                <p className="mt-3 text-sm leading-6 text-zinc-500">
                  Sign in to continue to your financial command center.
                </p>
              </div>

              {/* ====================================================
                  FORM FIELDS
              ==================================================== */}
              <div className="mt-9 space-y-5">
                {/* Email */}
                <div>
                  <label
                    htmlFor="email"
                    className="mb-2.5 block text-xs font-medium uppercase tracking-[0.18em] text-zinc-500"
                  >
                    Email
                  </label>

                  <input
                    id="email"
                    name="email"
                    type="email"
                    required
                    autoComplete="email"
                    placeholder="you@company.com"
                    className="h-14 w-full rounded-xl border border-white/[0.08] bg-black/20 px-4 text-sm text-zinc-100 outline-none transition placeholder:text-zinc-700 focus:border-[#D4AF37]/40 focus:bg-black/30 focus:ring-1 focus:ring-[#D4AF37]/10"
                  />
                </div>

                {/* Password */}
                <div>
                  <div className="mb-2.5 flex items-center justify-between">
                    <label
                      htmlFor="password"
                      className="block text-xs font-medium uppercase tracking-[0.18em] text-zinc-500"
                    >
                      Password
                    </label>

                    <Link
                      href="/forgot-password"
                      className="text-xs font-medium text-zinc-500 transition-colors hover:text-[#D4AF37]"
                    >
                      Forgot password?
                    </Link>
                  </div>

                  <input
                    id="password"
                    name="password"
                    type="password"
                    required
                    autoComplete="current-password"
                    placeholder="Enter your password"
                    className="h-14 w-full rounded-xl border border-white/[0.08] bg-black/20 px-4 text-sm text-zinc-100 outline-none transition placeholder:text-zinc-700 focus:border-[#D4AF37]/40 focus:bg-black/30 focus:ring-1 focus:ring-[#D4AF37]/10"
                  />
                </div>
              </div>

              {/* Sign In */}
              <button
                type="submit"
                className="mt-8 flex h-14 w-full items-center justify-center rounded-xl bg-[#D4AF37] text-sm font-semibold text-[#090A0B] transition duration-200 hover:brightness-110 hover:shadow-[0_0_30px_rgba(212,175,55,0.12)] active:scale-[0.995]"
              >
                Sign In
              </button>

              {/* Sign Up */}
              <div className="mt-7 border-t border-white/[0.06] pt-7 text-center">
                <p className="text-sm text-zinc-600">
                  Don&apos;t have an account?{" "}
                  <Link
                    href="/signup"
                    className="font-medium text-[#D4AF37] transition hover:text-[#E5C65A]"
                  >
                    Create one
                  </Link>
                </p>
              </div>

              {/* Footer */}
              <p className="mt-8 text-center text-[10px] uppercase tracking-[0.25em] text-zinc-700">
                Secure financial workspace
              </p>
            </form>
          </div>
        </div>
      </div>
    </main>
  );
}