"use client";

import Link from "next/link";

export default function HomePage() {
  return (
    <main
      style={{
        minHeight: "100vh",
        background: "#070809",
        color: "#ffffff",
        padding: "80px 24px",
      }}
    >
      <div
        style={{
          maxWidth: "1100px",
          margin: "0 auto",
        }}
      >
        <p
          style={{
            color: "#D4AF37",
            fontSize: "12px",
            letterSpacing: "0.2em",
            textTransform: "uppercase",
          }}
        >
          DhanarkOS
        </p>

        <h1
          style={{
            marginTop: "20px",
            fontSize: "64px",
            fontWeight: 300,
            lineHeight: 1,
          }}
        >
          Capital.
          <br />
          <span style={{ color: "#666666" }}>
            Mastered.
          </span>
        </h1>

        <p
          style={{
            marginTop: "24px",
            maxWidth: "600px",
            color: "#777777",
            fontSize: "16px",
            lineHeight: 1.7,
          }}
        >
          DhanarkOS gives growing businesses one intelligent
          command center to understand money, manage
          financial operations and make better decisions.
        </p>

        <div
          style={{
            display: "flex",
            gap: "12px",
            marginTop: "32px",
          }}
        >
          <Link
            href="/signup"
            style={{
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
              height: "44px",
              padding: "0 20px",
              borderRadius: "10px",
              background: "#D4AF37",
              color: "#000000",
              textDecoration: "none",
              fontSize: "13px",
              fontWeight: 600,
            }}
          >
            Start Free Trial
          </Link>

          <Link
            href="/login"
            style={{
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
              height: "44px",
              padding: "0 20px",
              borderRadius: "10px",
              border: "1px solid rgba(255,255,255,0.1)",
              color: "#ffffff",
              textDecoration: "none",
              fontSize: "13px",
            }}
          >
            Login
          </Link>
        </div>
      </div>
    </main>
  );
}