import type { Metadata } from "next";
import "./globals.css";
import QueryProvider from "@/providers/QueryProvider";

export const metadata: Metadata = {
  title: "DhanarkOS",
  description:
    "The Financial Operating System for Modern Businesses",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="h-full antialiased">
      <body className="min-h-full bg-[#070809] text-white">
        <QueryProvider>{children}</QueryProvider>
      </body>
    </html>
  );
}