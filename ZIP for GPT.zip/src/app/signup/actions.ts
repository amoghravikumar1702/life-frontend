"use server";

import { cookies, headers } from "next/headers";
import { redirect } from "next/navigation";
import crypto from "crypto";

import { createClient } from "@/lib/supabase/server";

import {
  checkSignupRateLimit,
  recordSignupAttempt,
  recordSuccessfulSignup,
} from "@/lib/server/signup-rate-limit";

const DEVICE_COOKIE = "dhanarkos_device_id";

function createDeviceId() {
  return crypto.randomBytes(32).toString("hex");
}

function redirectWithError(
  message: string
): never {
  redirect(
    `/signup?error=${encodeURIComponent(message)}`
  );
}

export async function signUp(
  formData: FormData
) {
  /*
   * ============================================================
   * INPUT
   * ============================================================
   */

  const email = String(
    formData.get("email") ?? ""
  )
    .trim()
    .toLowerCase();

  const password = String(
    formData.get("password") ?? ""
  );

  /*
   * ============================================================
   * VALIDATION
   * ============================================================
   */

  if (!email) {
    redirectWithError(
      "Please enter your email address."
    );
  }

  if (!email.includes("@")) {
    redirectWithError(
      "Please enter a valid email address."
    );
  }

  if (!password) {
    redirectWithError(
      "Please enter a password."
    );
  }

  if (password.length < 6) {
    redirectWithError(
      "Password must be at least 6 characters."
    );
  }

  /*
   * ============================================================
   * DEVICE COOKIE
   * ============================================================
   */

  const cookieStore = await cookies();

  let deviceId =
    cookieStore.get(DEVICE_COOKIE)?.value;

  /*
   * Create a first-party device identifier
   * when this browser does not already have one.
   */

  if (!deviceId) {
    deviceId = createDeviceId();

    cookieStore.set(
      DEVICE_COOKIE,
      deviceId,
      {
        httpOnly: true,

        secure:
          process.env.NODE_ENV ===
          "production",

        sameSite: "lax",

        path: "/",

        maxAge:
          60 *
          60 *
          24 *
          365,
      }
    );
  }

  /*
   * ============================================================
   * REQUEST IP
   * ============================================================
   */

  const requestHeaders =
    await headers();

  const forwardedFor =
    requestHeaders.get(
      "x-forwarded-for"
    );

  const realIp =
    requestHeaders.get(
      "x-real-ip"
    );

  const ip =
    forwardedFor
      ?.split(",")[0]
      ?.trim() ??
    realIp ??
    "unknown";

  /*
   * ============================================================
   * RATE LIMIT — IP
   * ============================================================
   */

  if (ip !== "unknown") {
    const ipLimit =
      await checkSignupRateLimit(
        "ip",
        ip
      );

    if (!ipLimit.allowed) {
      redirectWithError(
        ipLimit.reason ===
          "already_used"
          ? "This network has already been used to create a DhanarkOS trial recently."
          : "Too many signup attempts. Please try again later."
      );
    }
  }

  /*
   * ============================================================
   * RATE LIMIT — DEVICE
   * ============================================================
   */

  const deviceLimit =
    await checkSignupRateLimit(
      "device",
      deviceId
    );

  if (!deviceLimit.allowed) {
    redirectWithError(
      deviceLimit.reason ===
        "already_used"
        ? "This device has already been used to create a DhanarkOS trial recently."
        : "Too many signup attempts from this device. Please try again later."
    );
  }

  /*
   * ============================================================
   * RATE LIMIT — EMAIL
   * ============================================================
   */

  const emailLimit =
    await checkSignupRateLimit(
      "email",
      email
    );

  if (!emailLimit.allowed) {
    redirectWithError(
      emailLimit.reason ===
        "already_used"
        ? "This email has already been used to create a DhanarkOS trial recently."
        : "Too many signup attempts for this email. Please try again later."
    );
  }

  /*
   * ============================================================
   * RECORD ATTEMPTS
   * ============================================================
   */

  if (ip !== "unknown") {
    await recordSignupAttempt(
      "ip",
      ip
    );
  }

  await recordSignupAttempt(
    "device",
    deviceId
  );

  await recordSignupAttempt(
    "email",
    email
  );

  /*
   * ============================================================
   * SUPABASE AUTH
   * ============================================================
   */

  const supabase =
    await createClient();

  /*
   * IMPORTANT:
   *
   * Use the existing NEXT_PUBLIC_APP_URL.
   * Do NOT create NEXT_PUBLIC_SITE_URL.
   */

  const appUrl =
    process.env.NEXT_PUBLIC_APP_URL ??
    "http://localhost:3000";

  const {
    data,
    error,
  } =
    await supabase.auth.signUp({
      email,
      password,

      options: {
        emailRedirectTo:
          `${appUrl}/auth/callback?next=/pricing`,
      },
    });

  /*
   * ============================================================
   * SUPABASE ERROR
   * ============================================================
   */

  if (error) {
    console.error(
      "[DhanarkOS Signup] Supabase signup failed:",
      error
    );

    redirectWithError(
      "Unable to create your account. Please check your details and try again."
    );
  }

  if (!data.user) {
    redirectWithError(
      "Your account could not be created. Please try again."
    );
  }

  /*
   * ============================================================
   * SUCCESSFUL SIGNUP
   * ============================================================
   *
   * Lock this IP/device/email for 24 hours.
   */

  if (ip !== "unknown") {
    await recordSuccessfulSignup(
      "ip",
      ip
    );
  }

  await recordSuccessfulSignup(
    "device",
    deviceId
  );

  await recordSuccessfulSignup(
    "email",
    email
  );

  /*
   * ============================================================
   * EMAIL VERIFICATION
   * ============================================================
   */

  if (!data.session) {
    redirect(
      `/signup?success=${encodeURIComponent(
        "Account created. Check your email to verify your account."
      )}`
    );
  }

  /*
   * ============================================================
   * AUTHENTICATED
   * ============================================================
   */

  redirect("/pricing");
}