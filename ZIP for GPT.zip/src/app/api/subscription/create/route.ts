import { NextRequest } from "next/server";

import { ApiResponse } from "@/lib/api-response";
import { handleApiError } from "@/lib/error-handler";
import { razorpay } from "@/lib/server/razorpay";
import { createClient } from "@/lib/supabase/server";

type PlanKey =
  | "beginner"
  | "professional"
  | "advanced";

type PlanConfig = {
  name: string;
  planId: string;
  amount: number;
};

type TrialRecord = {
  id: number;
  trial_status: string | null;
  subscription_status: string | null;
  razorpay_subscription_id: string | null;
};

const PLANS: Record<
  PlanKey,
  PlanConfig
> = {
  beginner: {
    name: "DhanarkOS Beginner",
    planId:
      "plan_TTUEYNaTgoKvyj",
    amount: 799,
  },

  professional: {
    name: "DhanarkOS Professional",
    planId:
      "plan_TTUFtLakXhYU9f",
    amount: 1699,
  },

  advanced: {
    name: "DhanarkOS Advanced",
    planId:
      "plan_TTUGnz0lC0upNs",
    amount: 1999,
  },
};

/*
 * ============================================================
 * DhanarkOS TRIAL
 * ============================================================
 *
 * Razorpay does not require the trial to be configured on the
 * Plan itself.
 *
 * We create the trial by setting the Subscription's start_at
 * seven days into the future.
 *
 * The customer authorizes the subscription today.
 * Razorpay starts recurring billing seven days later.
 */

const TRIAL_DAYS = 7;

const TRIAL_MILLISECONDS =
  TRIAL_DAYS *
  24 *
  60 *
  60 *
  1000;

export async function POST(
  request: NextRequest
) {
  try {
    /*
     * ============================================================
     * AUTHENTICATION
     * ============================================================
     */

    const supabase =
      await createClient();

    const {
      data: { user },
      error: authError,
    } =
      await supabase.auth.getUser();

    if (authError) {
      console.error(
        "[DhanarkOS Subscription] Auth error:",
        authError
      );

      return ApiResponse.error(
        "Unable to verify your account.",
        401
      );
    }

    if (!user) {
      return ApiResponse.error(
        "You must be signed in to start a DhanarkOS trial.",
        401
      );
    }

    /*
     * ============================================================
     * READ PLAN
     * ============================================================
     */

    const body =
      await request.json();

    const plan =
      body?.plan as PlanKey;

    if (
      !plan ||
      !Object.prototype.hasOwnProperty.call(
        PLANS,
        plan
      )
    ) {
      return ApiResponse.error(
        "Please select a valid DhanarkOS plan.",
        400
      );
    }

    const planConfig =
      PLANS[plan];

    /*
     * ============================================================
     * FIND EXISTING TRIAL
     * ============================================================
     */

    const {
      data: rawTrial,
      error: trialLookupError,
    } =
      await supabase
        .from("dhanarkos_trials")
        .select(
          "id, trial_status, subscription_status, razorpay_subscription_id"
        )
        .eq(
          "user_id",
          user.id
        )
        .maybeSingle();

    if (trialLookupError) {
      console.error(
        "[DhanarkOS Subscription] Trial lookup failed:",
        trialLookupError
      );

      return ApiResponse.error(
        "Unable to verify your DhanarkOS trial.",
        500
      );
    }

    const trial =
      rawTrial as TrialRecord | null;

    /*
     * ============================================================
     * PREVENT DUPLICATE SUBSCRIPTIONS
     * ============================================================
     */

    if (
      trial?.razorpay_subscription_id
    ) {
      return ApiResponse.error(
        "A DhanarkOS subscription has already been created for this account.",
        400
      );
    }

    /*
     * ============================================================
     * CALCULATE TRIAL END
     * ============================================================
     */

    const now =
      Date.now();

    const trialEndsAt =
      new Date(
        now +
          TRIAL_MILLISECONDS
      );

    /*
     * Razorpay expects Unix time in seconds.
     */

    const startAt =
      Math.floor(
        trialEndsAt.getTime() /
          1000
      );

    /*
     * ============================================================
     * CREATE RAZORPAY SUBSCRIPTION
     * ============================================================
     *
     * The subscription starts seven days from now.
     *
     * Therefore:
     *
     *   Day 0 → authorization
     *   Day 1 → free trial
     *   ...
     *   Day 7 → subscription begins
     *   Day 7 → recurring billing starts
     *
     * This is Razorpay's supported way of creating a custom
     * subscription trial period.
     */

    const subscription =
      await razorpay.subscriptions.create({
        plan_id:
          planConfig.planId,

        total_count:
          120,

        quantity:
          1,

        customer_notify:
          true,

        start_at:
          startAt,

        notes: {
          product:
            "DhanarkOS",

          userId:
            user.id,

          plan:
            plan,

          planName:
            planConfig.name,

          amount:
            String(
              planConfig.amount
            ),

          trialDays:
            String(
              TRIAL_DAYS
            ),

          trialEndsAt:
            trialEndsAt.toISOString(),
        },
      });

    if (
      !subscription?.id
    ) {
      return ApiResponse.error(
        "Razorpay did not return a subscription ID.",
        500
      );
    }

    /*
     * ============================================================
     * SAVE SUBSCRIPTION
     * ============================================================
     */

    if (trial) {
      const {
        error: updateError,
      } =
        await supabase
          .from(
            "dhanarkos_trials"
          )
          .update({
            razorpay_subscription_id:
              subscription.id,

            selected_plan:
              plan,

            subscription_plan_id:
              planConfig.planId,

            trial_status:
              "pending",

            subscription_status:
              "none",

            trial_ends_at:
              trialEndsAt.toISOString(),
          })
          .eq(
            "id",
            trial.id
          )
          .eq(
            "user_id",
            user.id
          );

      if (updateError) {
        console.error(
          "[DhanarkOS Subscription] Subscription save failed:",
          updateError
        );

        /*
         * IMPORTANT:
         *
         * Razorpay has already created the subscription.
         * We therefore do not pretend the operation succeeded.
         */

        return ApiResponse.error(
          "Your Razorpay subscription was created, but DhanarkOS could not save it. Please contact support before trying again.",
          500
        );
      }
    } else {
      /*
       * ==========================================================
       * NO TRIAL RECORD
       * ==========================================================
       *
       * This is useful for the new-user flow where the customer
       * reaches billing before onboarding.
       *
       * company_id is intentionally not supplied here because
       * onboarding has not necessarily created the company yet.
       */

      const {
        error: insertError,
      } =
        await supabase
          .from(
            "dhanarkos_trials"
          )
          .insert({
            user_id:
              user.id,

            trial_status:
              "pending",

            subscription_status:
              "none",

            selected_plan:
              plan,

            subscription_plan_id:
              planConfig.planId,

            razorpay_subscription_id:
              subscription.id,

            trial_ends_at:
              trialEndsAt.toISOString(),
          });

      if (insertError) {
        console.error(
          "[DhanarkOS Subscription] Trial creation failed:",
          insertError
        );

        return ApiResponse.error(
          "Your Razorpay subscription was created, but DhanarkOS could not save your trial. Please contact support before trying again.",
          500
        );
      }
    }

    /*
     * ============================================================
     * SUCCESS
     * ============================================================
     */

    console.log(
      "[DhanarkOS Subscription] Subscription created:",
      {
        userId:
          user.id,

        subscriptionId:
          subscription.id,

        plan,

        planId:
          planConfig.planId,

        trialEndsAt:
          trialEndsAt.toISOString(),
      }
    );

    return ApiResponse.success({
      subscriptionId:
        subscription.id,

      plan,

      planName:
        planConfig.name,

      planId:
        planConfig.planId,

      amount:
        planConfig.amount,

      currency:
        "INR",

      trialDays:
        TRIAL_DAYS,

      trialEndsAt:
        trialEndsAt.toISOString(),

      startAt,

      keyId:
        process.env
          .NEXT_PUBLIC_RAZORPAY_KEY_ID,
    });
  } catch (error) {
    console.error(
      "[DhanarkOS Subscription] Create subscription error:",
      error
    );

    return handleApiError(
      error
    );
  }
}