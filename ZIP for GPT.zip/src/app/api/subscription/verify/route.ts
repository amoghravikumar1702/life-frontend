import { NextRequest } from "next/server";
import crypto from "crypto";

import { ApiResponse } from "@/lib/api-response";
import { handleApiError } from "@/lib/error-handler";
import { razorpay } from "@/lib/server/razorpay";
import { supabaseAdmin } from "@/lib/server/supabase";
import { createClient } from "@/lib/supabase/server";

type VerifyBody = {
  razorpay_payment_id?: string;
  razorpay_subscription_id?: string;
  razorpay_signature?: string;
};

type TrialRecord = {
  id: number;
  user_id: string;
  trial_status: string | null;
  subscription_status: string | null;
  razorpay_subscription_id: string | null;
  subscription_plan: string | null;
  subscription_billing_cycle: string | null;
};

export async function POST(request: NextRequest) {
  try {
    // ============================================================
    // AUTHENTICATION
    // ============================================================

    const supabase = await createClient();

    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser();

    if (authError || !user) {
      return ApiResponse.error(
        "You must be signed in to verify your subscription.",
        401
      );
    }

    // ============================================================
    // REQUEST BODY
    // ============================================================

    let body: VerifyBody;

    try {
      body = (await request.json()) as VerifyBody;
    } catch {
      return ApiResponse.error(
        "Invalid verification request.",
        400
      );
    }

    const paymentId =
      body.razorpay_payment_id?.trim();

    const subscriptionId =
      body.razorpay_subscription_id?.trim();

    const signature =
      body.razorpay_signature?.trim();

    if (
      !paymentId ||
      !subscriptionId ||
      !signature
    ) {
      return ApiResponse.error(
        "Incomplete Razorpay verification data.",
        400
      );
    }

    // ============================================================
    // FIND USER TRIAL
    // ============================================================

    const {
      data: trial,
      error: trialError,
    } = await supabaseAdmin
      .from("dhanarkos_trials")
      .select(
        `
          id,
          user_id,
          trial_status,
          subscription_status,
          razorpay_subscription_id,
          subscription_plan,
          subscription_billing_cycle
        `
      )
      .eq("user_id", user.id)
      .maybeSingle();

    if (trialError) {
      console.error(
        "[DhanarkOS Verify] Trial lookup failed:",
        trialError
      );

      return ApiResponse.error(
        "Unable to verify your DhanarkOS account.",
        500
      );
    }

    if (!trial) {
      return ApiResponse.error(
        "DhanarkOS trial record not found.",
        404
      );
    }

    const trialRecord =
      trial as TrialRecord;

    // ============================================================
    // SUBSCRIPTION OWNERSHIP
    // ============================================================

    if (
      trialRecord.razorpay_subscription_id &&
      trialRecord.razorpay_subscription_id !==
        subscriptionId
    ) {
      return ApiResponse.error(
        "This subscription does not belong to this DhanarkOS account.",
        403
      );
    }

    // ============================================================
    // RAZORPAY SECRET
    // ============================================================

    const razorpaySecret =
      process.env.RAZORPAY_KEY_SECRET;

    if (!razorpaySecret) {
      console.error(
        "[DhanarkOS Verify] RAZORPAY_KEY_SECRET is missing."
      );

      return ApiResponse.error(
        "Payment verification is not configured correctly.",
        500
      );
    }

    // ============================================================
    // VERIFY RAZORPAY SIGNATURE
    // ============================================================

    const expectedSignature =
      crypto
        .createHmac(
          "sha256",
          razorpaySecret
        )
        .update(
          `${paymentId}|${subscriptionId}`
        )
        .digest("hex");

    const expectedBuffer =
      Buffer.from(
        expectedSignature,
        "utf8"
      );

    const receivedBuffer =
      Buffer.from(
        signature,
        "utf8"
      );

    if (
      expectedBuffer.length !==
      receivedBuffer.length
    ) {
      console.error(
        "[DhanarkOS Verify] Signature length mismatch."
      );

      return ApiResponse.error(
        "Payment verification failed.",
        400
      );
    }

    const signatureValid =
      crypto.timingSafeEqual(
        expectedBuffer,
        receivedBuffer
      );

    if (!signatureValid) {
      console.error(
        "[DhanarkOS Verify] Invalid Razorpay signature.",
        {
          userId: user.id,
          subscriptionId,
          paymentId,
        }
      );

      return ApiResponse.error(
        "Payment verification failed.",
        400
      );
    }

    // ============================================================
    // VERIFY RAZORPAY SUBSCRIPTION
    // ============================================================

    let subscription;

    try {
      subscription =
        await razorpay.subscriptions.fetch(
          subscriptionId
        );
    } catch (error) {
      console.error(
        "[DhanarkOS Verify] Razorpay subscription fetch failed:",
        error
      );

      return ApiResponse.error(
        "Unable to verify the Razorpay subscription.",
        400
      );
    }

    if (
      !subscription ||
      subscription.id !== subscriptionId
    ) {
      return ApiResponse.error(
        "Razorpay subscription could not be verified.",
        400
      );
    }

    // ============================================================
    // DETERMINE TRIAL END
    // ============================================================

    const trialEndsAt =
      subscription.start_at
        ? new Date(
            Number(
              subscription.start_at
            ) * 1000
          ).toISOString()
        : new Date(
            Date.now() +
              7 *
                24 *
                60 *
                60 *
                1000
          ).toISOString();

    // ============================================================
    // PLAN INFORMATION
    // ============================================================

    const selectedPlan =
      trialRecord.subscription_plan;

    const billingCycle =
      trialRecord.subscription_billing_cycle ??
      "monthly";

    // ============================================================
    // ACTIVATE FREE TRIAL
    // ============================================================
    //
    // Razorpay authorization is complete.
    //
    // This does NOT mean the recurring subscription has already
    // been charged.
    //
    // Therefore:
    //
    // trial_status        = trialing
    // subscription_status = none
    //
    // The webhook will later move the subscription to active
    // when Razorpay processes the recurring charge.
    // ============================================================

    const {
      error: updateError,
    } = await supabaseAdmin
      .from("dhanarkos_trials")
      .update({
        razorpay_subscription_id:
          subscriptionId,

        razorpay_payment_id:
          paymentId,

        trial_status:
          "trialing",

        subscription_status:
          "none",

        trial_ends_at:
          trialEndsAt,

        subscription_plan:
          selectedPlan,

        subscription_billing_cycle:
          billingCycle,

        updated_at:
          new Date().toISOString(),
      })
      .eq(
        "id",
        trialRecord.id
      )
      .eq(
        "user_id",
        user.id
      );

    if (updateError) {
      console.error(
        "[DhanarkOS Verify] Trial activation failed:",
        updateError
      );

      return ApiResponse.error(
        "Razorpay authorization succeeded, but we could not activate your DhanarkOS trial.",
        500
      );
    }

    // ============================================================
    // SUCCESS
    // ============================================================

    console.log(
      "[DhanarkOS Verify] Trial activated successfully:",
      {
        userId:
          user.id,

        subscriptionId,

        paymentId,

        plan:
          selectedPlan,

        billingCycle,

        trialEndsAt,

        razorpayStatus:
          subscription.status,
      }
    );

    return ApiResponse.success({
      activated: true,

      trialStatus:
        "trialing",

      subscriptionStatus:
        "none",

      subscriptionId,

      paymentId,

      plan:
        selectedPlan,

      billingCycle,

      trialEndsAt,
    });
  } catch (error) {
    console.error(
      "[DhanarkOS Verify] Unexpected verification error:",
      error
    );

    return handleApiError(
      error
    );
  }
}