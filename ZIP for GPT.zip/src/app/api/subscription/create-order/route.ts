import { NextRequest } from "next/server";

import { ApiResponse } from "@/lib/api-response";
import { handleApiError } from "@/lib/error-handler";
import { razorpay } from "@/lib/server/razorpay";
import { supabaseAdmin } from "@/lib/server/supabase";
import { createClient } from "@/lib/supabase/server";

const PLANS = {
  beginner: {
    name: "Beginner",
    monthly: 799,
    yearly: 7999,
  },

  professional: {
    name: "Professional",
    monthly: 1699,
    yearly: 16999,
  },

  advanced: {
    name: "Advanced",
    monthly: 1999,
    yearly: 19999,
  },
} as const;

type PlanKey = keyof typeof PLANS;

type BillingCycle =
  | "monthly"
  | "yearly";

const TRIAL_DAYS = 7;

export async function POST(
  request: NextRequest
) {
  try {
    /*
     * ============================================================
     * AUTHENTICATION
     * ============================================================
     */

    const supabase =
      await createClient();

    const {
      data: { user },
      error: authError,
    } =
      await supabase.auth.getUser();

    if (authError || !user) {
      return ApiResponse.error(
        "You must be signed in to subscribe.",
        401
      );
    }

    /*
     * ============================================================
     * REQUEST
     * ============================================================
     */

    const body =
      await request.json();

    const plan =
      String(
        body.plan ?? ""
      ).toLowerCase() as PlanKey;

    const billingCycle =
      String(
        body.billingCycle ??
          "monthly"
      ).toLowerCase() as BillingCycle;

    if (!PLANS[plan]) {
      return ApiResponse.error(
        "Invalid subscription plan.",
        400
      );
    }

    if (
      billingCycle !== "monthly" &&
      billingCycle !== "yearly"
    ) {
      return ApiResponse.error(
        "Invalid billing cycle.",
        400
      );
    }

    const selectedPlan =
      PLANS[plan];

    /*
     * ============================================================
     * FIND USER TRIAL
     * ============================================================
     */

    const {
      data: trial,
      error: trialError,
    } =
      await supabaseAdmin
        .from("dhanarkos_trials")
        .select(
          `
            id,
            user_id,
            trial_status,
            subscription_status
          `
        )
        .eq(
          "user_id",
          user.id
        )
        .maybeSingle();

    if (trialError) {
      console.error(
        "[Subscription] Trial lookup failed:",
        trialError
      );

      return ApiResponse.error(
        "Unable to verify your subscription status.",
        500
      );
    }

    if (!trial) {
      return ApiResponse.error(
        "Subscription record not found.",
        404
      );
    }

    if (
      trial.subscription_status ===
      "active"
    ) {
      return ApiResponse.error(
        "Your subscription is already active.",
        400
      );
    }

    /*
     * ============================================================
     * RAZORPAY PLAN
     * ============================================================
     *
     * Razorpay Subscriptions require an existing Razorpay Plan.
     *
     * We select the correct Plan ID from .env.local based on:
     *
     * beginner / professional / advanced
     *
     * AND
     *
     * monthly / yearly
     *
     * Example:
     *
     * RAZORPAY_PLAN_BEGINNER_MONTHLY
     * RAZORPAY_PLAN_BEGINNER_YEARLY
     *
     * RAZORPAY_PLAN_PROFESSIONAL_MONTHLY
     * RAZORPAY_PLAN_PROFESSIONAL_YEARLY
     *
     * RAZORPAY_PLAN_ADVANCED_MONTHLY
     * RAZORPAY_PLAN_ADVANCED_YEARLY
     */

    const planEnvironmentKey =
      `RAZORPAY_PLAN_${plan.toUpperCase()}_${billingCycle.toUpperCase()}`;

    const razorpayPlanId =
      process.env[
        planEnvironmentKey
      ]?.trim();

    if (!razorpayPlanId) {
      console.error(
        "[Subscription] Missing Razorpay plan ID:",
        planEnvironmentKey
      );

      return ApiResponse.error(
        `Razorpay plan is not configured for ${selectedPlan.name} ${billingCycle}.`,
        500
      );
    }

    /*
     * ============================================================
     * VERIFY RAZORPAY PLAN
     * ============================================================
     *
     * Before creating the subscription, ask Razorpay whether
     * this Plan ID actually exists.
     *
     * This catches:
     *
     * - Wrong Plan ID
     * - Typo in .env.local
     * - Monthly/yearly mismatch
     * - Test/Live mode mismatch
     * - Wrong Razorpay account
     */

    let razorpayPlan;

    try {
      razorpayPlan =
        await razorpay.plans.fetch(
          razorpayPlanId
        );

      console.log(
        "[Subscription] Razorpay plan verified:",
        {
          id:
            razorpayPlan.id,

          name:
            razorpayPlan.item
              ?.name,

          amount:
            razorpayPlan.item
              ?.amount,

          period:
            razorpayPlan.period,

          interval:
            razorpayPlan.interval,
        }
      );
    } catch (error) {
      console.error(
        "[Subscription] Razorpay plan lookup failed:",
        {
          planEnvironmentKey,
          razorpayPlanId,
          error,
        }
      );

      return ApiResponse.error(
        `The Razorpay ${selectedPlan.name} ${billingCycle} plan ID is invalid or belongs to a different Razorpay mode/account.`,
        400
      );
    }

    /*
     * ============================================================
     * OPTIONAL PLAN SAFETY CHECK
     * ============================================================
     *
     * Verify that the Razorpay Plan actually matches the selected
     * billing cycle.
     *
     * This prevents accidentally using a monthly Plan ID for a
     * yearly subscription or vice versa.
     */

    const expectedPeriod =
      billingCycle ===
      "monthly"
        ? "monthly"
        : "yearly";

    if (
      razorpayPlan.period &&
      razorpayPlan.period !==
        expectedPeriod
    ) {
      console.error(
        "[Subscription] Razorpay plan period mismatch:",
        {
          planEnvironmentKey,
          razorpayPlanId,
          expectedPeriod,
          actualPeriod:
            razorpayPlan.period,
        }
      );

      return ApiResponse.error(
        `The configured Razorpay plan does not match the ${billingCycle} billing cycle.`,
        400
      );
    }

    /*
     * ============================================================
     * CREATE RAZORPAY SUBSCRIPTION
     * ============================================================
     *
     * IMPORTANT:
     *
     * We do NOT create a Razorpay Order here.
     *
     * We create a Razorpay Subscription linked to the verified
     * Razorpay Plan.
     */

    const totalCount =
      billingCycle ===
      "monthly"
        ? 120
        : 10;

    const subscription =
      await razorpay.subscriptions.create(
        {
          plan_id:
            razorpayPlanId,

          total_count:
            totalCount,

          start_at:
            Math.floor(
              Date.now() / 1000
            ) +
            TRIAL_DAYS *
              24 *
              60 *
              60,

          customer_notify: 1,

          notes: {
            userId:
              user.id,

            trialId:
              trial.id,

            plan,

            planName:
              selectedPlan.name,

            billingCycle,

            trialDays:
              String(
                TRIAL_DAYS
              ),

            product:
              "DhanarkOS",
          },
        }
      );

    /*
     * ============================================================
     * VALIDATE SUBSCRIPTION
     * ============================================================
     */

    if (
      !subscription ||
      !subscription.id
    ) {
      console.error(
        "[Subscription] Razorpay returned no subscription ID:",
        subscription
      );

      return ApiResponse.error(
        "Razorpay did not create a subscription.",
        502
      );
    }

    /*
     * ============================================================
     * STORE SUBSCRIPTION INFORMATION
     * ============================================================
     */

    const {
      error: updateError,
    } =
      await supabaseAdmin
        .from("dhanarkos_trials")
        .update({
          subscription_plan:
            plan,

          subscription_billing_cycle:
            billingCycle,

          razorpay_subscription_id:
            subscription.id,

          updated_at:
            new Date().toISOString(),
        })
        .eq(
          "id",
          trial.id
        )
        .eq(
          "user_id",
          user.id
        );

    if (updateError) {
      console.error(
        "[Subscription] Failed to save Razorpay subscription:",
        updateError
      );

      return ApiResponse.error(
        "Your subscription was created, but we could not save it to your DhanarkOS account. Please contact support before trying again.",
        500
      );
    }

    /*
     * ============================================================
     * RETURN CHECKOUT DATA
     * ============================================================
     */

    return ApiResponse.success({
      subscriptionId:
        subscription.id,

      keyId:
        process.env
          .NEXT_PUBLIC_RAZORPAY_KEY_ID,

      plan,

      planName:
        selectedPlan.name,

      planId:
        razorpayPlanId,

      billingCycle,

      trialDays:
        TRIAL_DAYS,

      status:
        subscription.status,
    });
  } catch (error) {
    console.error(
      "[Subscription] CREATE SUBSCRIPTION ERROR:",
      error
    );

    return handleApiError(
      error
    );
  }
}