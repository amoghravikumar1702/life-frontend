import crypto from "crypto";

import { supabaseAdmin } from "@/lib/server/supabase";

const ATTEMPT_WINDOW_MS =
  15 * 60 * 1000;

const MAX_ATTEMPTS_PER_WINDOW = 5;

const SUCCESS_COOLDOWN_MS =
  24 * 60 * 60 * 1000;

type IdentifierType =
  | "ip"
  | "device"
  | "email";

type RateLimitResult = {
  allowed: boolean;
  reason?:
    | "rate_limited"
    | "already_used";
  retryAfterSeconds?: number;
};

function hashIdentifier(
  value: string
) {
  const pepper =
    process.env.RATE_LIMIT_SECRET;

  if (!pepper) {
    throw new Error(
      "RATE_LIMIT_SECRET is not configured."
    );
  }

  return crypto
    .createHmac(
      "sha256",
      pepper
    )
    .update(value)
    .digest("hex");
}

function secondsUntil(
  timestamp: number
) {
  return Math.max(
    1,
    Math.ceil(
      (timestamp -
        Date.now()) /
        1000
    )
  );
}

export async function checkSignupRateLimit(
  type: IdentifierType,
  identifier: string
): Promise<RateLimitResult> {
  const normalized =
    identifier.trim().toLowerCase();

  if (!normalized) {
    return {
      allowed: false,
      reason: "rate_limited",
    };
  }

  const hash =
    hashIdentifier(normalized);

  const {
    data: existing,
    error: lookupError,
  } =
    await supabaseAdmin
      .from(
        "dhanarkos_signup_rate_limits"
      )
      .select(
        `
          id,
          attempt_count,
          window_started_at,
          successful_signup_at
        `
      )
      .eq(
        "identifier_type",
        type
      )
      .eq(
        "identifier_hash",
        hash
      )
      .maybeSingle();

  if (lookupError) {
    console.error(
      "[Signup Rate Limit] Lookup failed:",
      lookupError
    );

    throw new Error(
      "Unable to verify signup rate limit."
    );
  }

  if (!existing) {
    return {
      allowed: true,
    };
  }

  // ============================================================
  // SUCCESSFUL SIGNUP COOLDOWN
  // ============================================================

  if (
    existing.successful_signup_at
  ) {
    const successfulAt =
      new Date(
        existing.successful_signup_at
      ).getTime();

    const expiresAt =
      successfulAt +
      SUCCESS_COOLDOWN_MS;

    if (
      expiresAt >
      Date.now()
    ) {
      return {
        allowed: false,
        reason:
          "already_used",
        retryAfterSeconds:
          secondsUntil(
            expiresAt
          ),
      };
    }
  }

  // ============================================================
  // ATTEMPT WINDOW
  // ============================================================

  const windowStartedAt =
    new Date(
      existing.window_started_at
    ).getTime();

  const windowExpiresAt =
    windowStartedAt +
    ATTEMPT_WINDOW_MS;

  if (
    windowExpiresAt <=
    Date.now()
  ) {
    return {
      allowed: true,
    };
  }

  if (
    existing.attempt_count >=
    MAX_ATTEMPTS_PER_WINDOW
  ) {
    return {
      allowed: false,
      reason:
        "rate_limited",
      retryAfterSeconds:
        secondsUntil(
          windowExpiresAt
        ),
    };
  }

  return {
    allowed: true,
  };
}

export async function recordSignupAttempt(
  type: IdentifierType,
  identifier: string
) {
  const normalized =
    identifier.trim().toLowerCase();

  if (!normalized) {
    return;
  }

  const hash =
    hashIdentifier(normalized);

  const now =
    new Date();

  const {
    data: existing,
    error: lookupError,
  } =
    await supabaseAdmin
      .from(
        "dhanarkos_signup_rate_limits"
      )
      .select(
        `
          id,
          attempt_count,
          window_started_at
        `
      )
      .eq(
        "identifier_type",
        type
      )
      .eq(
        "identifier_hash",
        hash
      )
      .maybeSingle();

  if (lookupError) {
    console.error(
      "[Signup Rate Limit] Attempt lookup failed:",
      lookupError
    );

    throw new Error(
      "Unable to record signup attempt."
    );
  }

  if (!existing) {
    const {
      error,
    } =
      await supabaseAdmin
        .from(
          "dhanarkos_signup_rate_limits"
        )
        .insert({
          identifier_type:
            type,

          identifier_hash:
            hash,

          attempt_count:
            1,

          window_started_at:
            now.toISOString(),

          last_attempt_at:
            now.toISOString(),

          updated_at:
            now.toISOString(),
        });

    if (error) {
      console.error(
        "[Signup Rate Limit] Insert failed:",
        error
      );

      throw new Error(
        "Unable to record signup attempt."
      );
    }

    return;
  }

  const windowStartedAt =
    new Date(
      existing.window_started_at
    ).getTime();

  const windowExpired =
    windowStartedAt +
      ATTEMPT_WINDOW_MS <=
    Date.now();

  const nextAttemptCount =
    windowExpired
      ? 1
      : existing.attempt_count + 1;

  const updatePayload =
    windowExpired
      ? {
          attempt_count: 1,
          window_started_at:
            now.toISOString(),
          last_attempt_at:
            now.toISOString(),
          updated_at:
            now.toISOString(),
        }
      : {
          attempt_count:
            nextAttemptCount,
          last_attempt_at:
            now.toISOString(),
          updated_at:
            now.toISOString(),
        };

  const {
    error,
  } =
    await supabaseAdmin
      .from(
        "dhanarkos_signup_rate_limits"
      )
      .update(
        updatePayload
      )
      .eq(
        "id",
        existing.id
      );

  if (error) {
    console.error(
      "[Signup Rate Limit] Update failed:",
      error
    );

    throw new Error(
      "Unable to record signup attempt."
    );
  }
}

export async function recordSuccessfulSignup(
  type: IdentifierType,
  identifier: string
) {
  const normalized =
    identifier.trim().toLowerCase();

  if (!normalized) {
    return;
  }

  const hash =
    hashIdentifier(normalized);

  const now =
    new Date().toISOString();

  const {
    error,
  } =
    await supabaseAdmin
      .from(
        "dhanarkos_signup_rate_limits"
      )
      .upsert(
        {
          identifier_type:
            type,

          identifier_hash:
            hash,

          attempt_count:
            0,

          successful_signup_at:
            now,

          last_attempt_at:
            now,

          updated_at:
            now,
        },
        {
          onConflict:
            "identifier_type,identifier_hash",
        }
      );

  if (error) {
    console.error(
      "[Signup Rate Limit] Successful signup recording failed:",
      error
    );

    throw new Error(
      "Unable to finalize signup rate limit."
    );
  }
}