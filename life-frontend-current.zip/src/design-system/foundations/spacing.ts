export const spacing = {
  xs: 8,

  sm: 16,

  md: 24,

  lg: 32,

  xl: 48,

  xxl: 64,

  section: 96,
} as const;